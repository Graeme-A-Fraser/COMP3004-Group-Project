package com.example.telidy.myapplication3;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector.SimpleOnScaleGestureListener;
import android.widget.ImageView;

public class GamePanel extends ImageView {
    Matrix matrix;
    float saveScale = 1;

    // The three states
    int NONE = 0;
    static final int DRAG = 1;
    static final int ZOOM = 2;
    int mode = NONE;

    // For zooming
    int minZoom = 1;
    int maxZoom = 3;
    float[] store;
    PointF startPoint = new PointF();
    PointF endPoint = new PointF();
    float originalScreenWidth;
    float originalScreenHeight;
    float screenWidth;
    float screenHeight;

    Context context;
    ScaleGestureDetector scaleGestureDetector;

    public void setMaxZoom(int max) {
        maxZoom = max;
    }

    public GamePanel(Context context) {
        super(context);
        handleZoomEvent(context);
    }

    private void handleZoomEvent(Context context) {
        super.setClickable(true);
        this.context = context;
        matrix = new Matrix();
        scaleGestureDetector = new ScaleGestureDetector(context, new ScaleGestureListener());
        store = new float[10];

        setImageMatrix(matrix);
        setScaleType(ScaleType.MATRIX);
        setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                scaleGestureDetector.onTouchEvent(event);
                PointF currentPoint = new PointF(event.getX(), event.getY());

              int action = event.getAction();

                // Fingers placed on the screen, get position
                if (action == MotionEvent.ACTION_DOWN) {
                    endPoint.set(currentPoint);
                    startPoint.set(endPoint);
                    mode = DRAG;
                }

                // Fingers dragging, get transformation
                if (action == MotionEvent.ACTION_MOVE && mode == DRAG) {
                    float dx = currentPoint.x - endPoint.x;
                    float dy = currentPoint.y - endPoint.y;
                    float contentSizeX = originalScreenWidth * saveScale;
                    float contentSizeY = originalScreenHeight * saveScale;
                    if (contentSizeX <= screenWidth) {
                        dx = 0;
                    }
                    if (contentSizeY <= screenHeight) {
                        dy = 0;
                    }
                    matrix.postTranslate(dx, dy);
                    transform();
                    endPoint.set(currentPoint.x, currentPoint.y);
                }

                // Fingers lifted up
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
                    mode = NONE;
                }
                setImageMatrix(matrix);
                return true;
            }
        });
    }

    private class ScaleGestureListener extends SimpleOnScaleGestureListener {
        @Override
        public boolean onScaleBegin(ScaleGestureDetector detector) {
            mode = ZOOM;
            return true;
        }

        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            float contentSizeX = originalScreenWidth * saveScale;
            float contentSizeY = originalScreenHeight * saveScale;
            float scaleFactor = detector.getScaleFactor();
            float originalScale = saveScale; // Save old values
            saveScale = scaleFactor * saveScale;

            if (saveScale > maxZoom) {
                saveScale = maxZoom;
                scaleFactor = maxZoom / originalScale;
            } else if (saveScale < minZoom) {
                saveScale = minZoom;
                scaleFactor = minZoom / originalScale;
            }

            if ((contentSizeX <= screenWidth) || (contentSizeY <= screenHeight)) {
                matrix.postScale(scaleFactor, scaleFactor, screenWidth / 2, screenHeight / 2);
            } else {
                matrix.postScale(scaleFactor, scaleFactor, detector.getFocusX(), detector.getFocusY());
            }
            transform();
            return true;
        }
    }

    @Override
    protected void onMeasure(int measureWidth, int measureHeight) {
        super.onMeasure(measureWidth, measureHeight);

        // Save measurements
        screenWidth = getWidth();
        screenHeight = getHeight();
        originalScreenWidth = screenWidth;
        originalScreenHeight = screenHeight;

        if (saveScale == 1) {
            Drawable drawable = getDrawable();
            int imageWidth = drawable.getIntrinsicWidth();
            int imageHeight = drawable.getIntrinsicHeight();

            // Scale
            final float scaleFactorX = screenWidth/imageWidth;
            final float scaleFactorY = screenHeight/imageHeight;
            matrix.setScale(scaleFactorX, scaleFactorY);

            // Center image when zoomed
            float leftoverX = screenWidth - (scaleFactorX * imageWidth);
            float leftoverY = screenHeight - (scaleFactorY * imageHeight);
            leftoverX = leftoverX/2;
            leftoverY = leftoverY/2;

            matrix.postTranslate(leftoverX, leftoverY);
            originalScreenWidth = screenWidth - 2 * leftoverX;
            originalScreenHeight = screenHeight - 2 * leftoverY;
            setImageMatrix(matrix);

        }
        transform();
    }

    void transform() {
        float minX;
        float maxX;
        float minY;
        float maxY;
        float contentSizeX = originalScreenWidth * saveScale;
        float contentSizeY = originalScreenHeight * saveScale;
        matrix.getValues(store);
        float transformedWidth = 0;
        float transformedHeight = 0;

        // Width check
        if (contentSizeX <= screenWidth) {
            minX = 0;
            maxX = screenWidth - contentSizeX;

        } else {
            minX = screenWidth - contentSizeX;
            maxX = 0;
        }

        if (store[Matrix.MTRANS_X] < minX) {
            transformedWidth = minX - store[Matrix.MTRANS_X];
        }

        if (store[Matrix.MTRANS_X] > maxX) {
            transformedWidth = maxX - store[Matrix.MTRANS_X];
        }

        // Height check
        if (contentSizeY <= screenHeight) {
            minY = 0;
            maxY = screenHeight - contentSizeY;

        } else {
            minY = screenHeight - contentSizeY;
            maxY = 0;
        }

        if (store[Matrix.MTRANS_Y] < minY) {
            transformedHeight = minY - store[Matrix.MTRANS_Y];
        }

        if (store[Matrix.MTRANS_X] > maxY) {
            transformedHeight = maxY - store[Matrix.MTRANS_Y];
        }

        if (transformedWidth != 0 || transformedHeight != 0) {
            matrix.postTranslate(transformedWidth, transformedHeight);
        }
    }
}